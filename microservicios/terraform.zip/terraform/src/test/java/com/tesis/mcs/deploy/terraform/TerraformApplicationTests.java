package com.tesis.mcs.deploy.terraform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TerraformApplicationTests {

	@Test
	void contextLoads() {
	}

}
