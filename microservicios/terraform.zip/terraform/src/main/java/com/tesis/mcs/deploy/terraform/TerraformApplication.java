package com.tesis.mcs.deploy.terraform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TerraformApplication {

	public static void main(String[] args) {
		SpringApplication.run(TerraformApplication.class, args);
	}

}
